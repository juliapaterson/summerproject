
concat_ch1.coords = [30 -43 -18];
concat_ch1.source_binarised_ch1 = source_binarised_ch1;
concat_ch1.source_raw_ch1 = source_raw_ch1;

concat_ch2.coords = [-32 -44 -22];
concat_ch2.source_binarised_ch2 = source_binarised_ch2;
concat_ch2.source_raw_ch2 = source_raw_ch2;

concat_ch3.coords = [5 35 -27];
concat_ch3.source_binarised_ch3 = source_binarised_ch3;
concat_ch3.source_raw_ch3=source_raw_ch3;

concat_ch4.coords = [-6 20 -27];
concat_ch4.source_binarised_ch4 = source_binarised_ch4;
concat_ch4.source_raw_ch4 = source_raw_ch4;