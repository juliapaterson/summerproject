%% PlotJK_AllConditions_and_MMN
clear all
close all
% counter, from 0
filepath = '/Users/egrow1/Desktop/New_SourceWaveforms_Trials_1_to_100_allConds/'

%% Do it for FACE trials

%LEFT ITG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_30 -43 -18_for_bfmSe_faces_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    facesA(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end

%RIGHT ITG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_-32 -44 -22_for_bfmSe_faces_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    facesB(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end

%LEFT OFG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_-6  20 -27_for_bfmSe_faces_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    facesC(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end



%RIGHT OFG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_5  35 -27_for_bfmSe_faces_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    facesD(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end


%Plot high MMN separate
figure(1)
plot_JackKnife(facesA, 'm', '-', -100:2:900);
hold on;
plot_JackKnife(facesB, 'b', '-', -100:2:900);
hold on;
plot_JackKnife(facesC, 'c', '-', -100:2:900);
hold on;
plot_JackKnife(facesD, 'r', '-', -100:2:900);
hold on;

% counter, from 0

%% Do it for RANDOM trials

%LEFT ITG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_30 -43 -18_for_bfmSe_random_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    randomA(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end

%RIGHT ITG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_-32 -44 -22_for_bfmSe_random_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    randomB(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end


%LEFT OFG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_-6  20 -27_for_bfmSe_random_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    randomC(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end

%RIGHT OFG
for trialNo = 1:200
    
    filename = ['Source_Waveform_at_5  35 -27_for_bfmSe_random_fspmeeg_7MJN_trial_' num2str(trialNo) '.mat']
    load ([filepath filename])
    
    randomD(trialNo,:) = waveform;                                                   % adds FCz data (101 x 4) to GM, ending at last count
    
end


%Plot high MMN separate
figure(2)
plot_JackKnife(randomA, 'm', '-', -100:2:900);
hold on;
plot_JackKnife(randomB, 'b', '-', -100:2:900);
hold on;
plot_JackKnife(randomC, 'c', '-', -100:2:900);
hold on;
plot_JackKnife(randomD, 'r', '-', -100:2:900);
hold on;